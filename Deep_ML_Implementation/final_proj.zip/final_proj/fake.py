import os
from pathlib import Path
import json

import streamlit as st
import geopandas as gpd
import pydeck as pdk
import pandas as pd
import numpy as np
import joblib
import rasterio
from rasterio.warp import transform

# ----------------------------
# Original paths (UNCHANGED)
# ----------------------------
gdb_path = "/Users/brianbare/Downloads/Deep_ML/NEWHANOVER.gdb"
dem_path = "/Users/brianbare/Downloads/Deep_ML/newhanover-DEM03/newhanover-DEM03.tif"

ART_DIR = Path(".")
MODEL_PATH = ART_DIR / "/Users/brianbare/PycharmProjects/DeepMLProj/hurricane_rf_model.joblib"
FEAT_PATH = ART_DIR / "//Users/brianbare/PycharmProjects/DeepMLProj/feature_columns.txt"
MEDIANS_PATH = ART_DIR / "/Users/brianbare/PycharmProjects/DeepMLProj/training_medians.json"

CENTER_LAT, CENTER_LON = 34.2257, -77.9447
NM_TO_M = 1852.0

#SATELLITE_STYLE = "mapbox://styles/mapbox/satellite-streets-v12"

# ----------------------------------------------
# Category presets
# ----------------------------------------------
CAT_PRESETS = {
    0: {"Max_Winds_kt": list(range(20, 64, 5)), "Central_Pressure": list(range(990, 1011, 5)), "RMW_nm": list(range(25, 70, 5)), "OCI_mb": list(range(120, 300, 10))},
    1: {"Max_Winds_kt": list(range(64, 83, 2)), "Central_Pressure": list(range(980, 1001, 5)), "RMW_nm": list(range(20, 60, 5)), "OCI_mb": list(range(140, 320, 10))},
    2: {"Max_Winds_kt": list(range(83, 96, 2)), "Central_Pressure": list(range(965, 980, 5)), "RMW_nm": list(range(15, 50, 5)), "OCI_mb": list(range(150, 330, 10))},
    3: {"Max_Winds_kt": list(range(96, 113, 2)), "Central_Pressure": list(range(945, 965, 5)), "RMW_nm": list(range(10, 40, 5)), "OCI_mb": list(range(160, 340, 10))},
    4: {"Max_Winds_kt": list(range(113, 137, 2)), "Central_Pressure": list(range(920, 945, 5)), "RMW_nm": list(range(8, 35, 5)), "OCI_mb": list(range(170, 350, 10))},
    5: {"Max_Winds_kt": list(range(137, 181, 2)), "Central_Pressure": list(range(870, 921, 5)), "RMW_nm": list(range(5, 30, 5)), "OCI_mb": list(range(180, 360, 10))},
}

def _exists(p: str | Path) -> bool:
    try:
        return Path(p).exists()
    except Exception:
        return False

# ----------------------------
# Data Loading
# ----------------------------
@st.cache_resource(show_spinner=False)
def load_addresses_df():
    if not _exists(gdb_path):
        st.warning(f"📂 Address GDB not found:\n{gdb_path}")
        return pd.DataFrame(columns=["lon", "lat", "Full_Address", "elevation", "color"])

    gdf = gpd.read_file(gdb_path, layer="NEWHANOVER")
    if gdf.crs is None:
        gdf.set_crs(epsg=2264, inplace=True)
    gdf = gdf.to_crs(epsg=4326)

    df = gdf[["geometry", "Full_Address"]].copy()
    df["lon"] = df.geometry.x
    df["lat"] = df.geometry.y
    df["color"] = [[0, 0, 255]] * len(df)
    df["elevation"] = 0.0
    return df

@st.cache_resource(show_spinner=False)
def attach_elevation(_df_in: pd.DataFrame) -> pd.DataFrame:
    df = _df_in.copy()
    if df.empty:
        return df

    if not _exists(dem_path):
        st.info(f"🗺️ DEM not found: {dem_path}")
        return df

    with rasterio.open(dem_path) as src:
        xs, ys = transform("EPSG:4326", src.crs, df["lon"].values, df["lat"].values)
        df["elevation"] = [val[0] for val in src.sample(zip(xs, ys))]

    df["elevation"] = df["elevation"].fillna(0.0)

    # 🔴 Color logic
    df["color"] = [
        [255, 0, 0] if elev < 4 else [0, 0, 255]
        for elev in df["elevation"]
    ]
    return df

@st.cache_resource(show_spinner=False)
def load_model_and_artifacts():
    if not (_exists(MODEL_PATH) and _exists(FEAT_PATH) and _exists(MEDIANS_PATH)):
        return None, [], pd.Series(dtype=float)

    rf = joblib.load(MODEL_PATH)
    with open(FEAT_PATH) as f:
        feature_cols = [ln.strip() for ln in f if ln.strip()]
    with open(MEDIANS_PATH) as f:
        train_medians = pd.Series(json.load(f))
    return rf, feature_cols, train_medians

# ----------------------------
# UI
# ----------------------------
st.set_page_config(page_title="Wilmington Hurricane Impact", layout="wide")
st.title("Wilmington Hurricane Impact Simulator")

base_df = load_addresses_df()
df = attach_elevation(base_df)

# Sidebar
st.sidebar.header("Hurricane Builder")
sshws = st.sidebar.selectbox("SSHWS", options=[0,1,2,3,4,5], index=2)

opts = CAT_PRESETS[sshws]
max_winds = st.sidebar.selectbox("Max Winds (kt)", options=opts["Max_Winds_kt"])
central_pressure = st.sidebar.selectbox("Central Pressure (mb)", options=opts["Central_Pressure"])
rmw = st.sidebar.selectbox("RMW (nm)", options=opts["RMW_nm"])
oci = st.sidebar.selectbox("OCI (mb)", options=opts["OCI_mb"])

predict_button = st.sidebar.button("Predict Hurricane Impact")

# Base layer
address_layer = pdk.Layer(
    "ScatterplotLayer",
    data=df,
    get_position="[lon, lat]",
    get_radius=30,
    get_fill_color="color",
    pickable=True,
    auto_highlight=True,
)

layers = [address_layer]

rf, FEATURE_COLS, TRAIN_MEDIANS = load_model_and_artifacts()
predicted_size_nm = None
radius_nm_used = None

if predict_button and rf:
    row = {
        "Lat": CENTER_LAT,
        "Long": CENTER_LON,
        "Central_Pressure": float(central_pressure),
        "Max_Winds_kt": float(max_winds),
        "RMW_nm": float(rmw),
        "OCI_mb": float(oci),
        "SSHWS": float(sshws),
        "Abs_Lat": abs(CENTER_LAT),
        "Wind_to_Pressure": float(max_winds)/(float(central_pressure)+1e-6),
    }

    X_new = pd.DataFrame([{c: row.get(c, np.nan) for c in FEATURE_COLS}])
    X_new = X_new.apply(pd.to_numeric, errors="coerce").fillna(TRAIN_MEDIANS).fillna(0.0)

    predicted_size_nm = float(rf.predict(X_new)[0])
    radius_nm_used = predicted_size_nm / 2.0
    radius_m = radius_nm_used * NM_TO_M

    hurricane_df = pd.DataFrame({
        "lon": [CENTER_LON],
        "lat": [CENTER_LAT],
        "radius_m": [radius_m],
        "color": [[128, 0, 128, 80]],
    })

    hurricane_layer = pdk.Layer(
        "ScatterplotLayer",
        data=hurricane_df,
        get_position="[lon, lat]",
        get_radius="radius_m",
        get_fill_color="color",
        stroked=True,
        filled=True,
        line_width_min_pixels=2,
    )
    layers.append(hurricane_layer)

# -------- NORMAL MAP VIEW --------
view_state = pdk.ViewState(
    longitude=CENTER_LON,
    latitude=CENTER_LAT,
    zoom=8,
    pitch=0
)

tooltip = {
    "html": "<b>Address:</b> {Full_Address}<br/><b>Elevation (m):</b> {elevation}",
    "style": {"backgroundColor": "white", "color": "black"}
}

st.pydeck_chart(
    pdk.Deck(
        map_style="mapbox://styles/mapbox/light-v11",  # ✅ clean normal map
        layers=layers,
        initial_view_state=view_state,
        tooltip=tooltip
    )
)

# Info
if predicted_size_nm:
    st.markdown(f"### Predicted Radius: **{radius_nm_used:.2f} nm**")


if predicted_size_nm:
    st.markdown(f"### Predicted Radius: **{radius_nm_used:.2f} nm**")

