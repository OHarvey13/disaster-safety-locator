# streamlit_hurricane_predictor.py  (robust: no circle until predict; category inputs; path checks; cache arg fix)
import os
from pathlib import Path
import json

import streamlit as st
import geopandas as gpd
import pandas as pd
import numpy as np
import joblib
import rasterio
from rasterio.warp import transform
try:
    import folium
    from streamlit_folium import st_folium
except Exception:
    folium = None
    st_folium = None

# ----------------------------
# Original paths (UNCHANGED)
# ----------------------------
gdb_path = "/Users/dimitrimontgomery/Downloads/CSC 432/Demo/NEWHANOVER.gdb"
dem_path = "/Users/dimitrimontgomery/Downloads/CSC 432/Demo/newhanover-DEM03/newhanover-DEM03.tif"

# Artifacts (kept exactly as you had them; absolute paths are fine)
ART_DIR = Path(".")
MODEL_PATH = ART_DIR / "/Users/dimitrimontgomery/Downloads/CSC 432/Demo/hurricane_rf_model.joblib"  # UPDATED: use the new neural-net joblib
FEAT_PATH = ART_DIR / "/Users/dimitrimontgomery/Downloads/CSC 432/Demo/feature_columns.txt"
MEDIANS_PATH = ART_DIR / "/Users/dimitrimontgomery/Downloads/CSC 432/Demo/training_medians.json"

# Wilmington center
CENTER_LAT, CENTER_LON = 34.2257, -77.9447
NM_TO_M = 1852.0  # nautical miles → meters

# ----------------------------------------------
# Category presets (SSHWS → dropdown value sets)
# ----------------------------------------------
CAT_PRESETS = {
    0: {"Max_Winds_kt": list(range(20, 64, 5)), "Central_Pressure": list(range(990, 1011, 5)), "RMW_nm": list(range(25, 70, 5)), "OCI_mb": list(range(120, 300, 10))},
    1: {"Max_Winds_kt": list(range(64, 83, 2)), "Central_Pressure": list(range(980, 1001, 5)), "RMW_nm": list(range(20, 60, 5)), "OCI_mb": list(range(140, 320, 10))},
    2: {"Max_Winds_kt": list(range(83, 96, 2)), "Central_Pressure": list(range(965, 980, 5)), "RMW_nm": list(range(15, 50, 5)), "OCI_mb": list(range(150, 330, 10))},
    3: {"Max_Winds_kt": list(range(96, 113, 2)), "Central_Pressure": list(range(945, 965, 5)), "RMW_nm": list(range(10, 40, 5)), "OCI_mb": list(range(160, 340, 10))},
    4: {"Max_Winds_kt": list(range(113, 137, 2)), "Central_Pressure": list(range(920, 945, 5)), "RMW_nm": list(range(8, 35, 5)), "OCI_mb": list(range(170, 350, 10))},
    5: {"Max_Winds_kt": list(range(137, 181, 2)), "Central_Pressure": list(range(870, 921, 5)), "RMW_nm": list(range(5, 30, 5)), "OCI_mb": list(range(180, 360, 10))},
}

# Session defaults to avoid missing-key errors
if "storm_center" not in st.session_state:
    st.session_state["storm_center"] = {"lat": CENTER_LAT, "lon": CENTER_LON}
if "waiting_for_click" not in st.session_state:
    st.session_state["waiting_for_click"] = False
if "pending_inputs" not in st.session_state:
    st.session_state["pending_inputs"] = None
if "predicted_size_nm" not in st.session_state:
    st.session_state["predicted_size_nm"] = None
if "radius_nm_used" not in st.session_state:
    st.session_state["radius_nm_used"] = None

def _exists(p: str | Path) -> bool:
    try:
        return Path(p).exists()
    except Exception:
        return False

# ----------------------------
# Caching
# ----------------------------
@st.cache_resource(show_spinner=False)
def load_addresses_df():
    """
    Load addresses from the FileGDB.
    If the GDB is missing/unavailable, return an empty DataFrame with required columns
    so the app still renders without crashing.
    """
    # Ensure columns exist even if empty
    empty_cols = ["lon", "lat", "Full_Address", "elevation", "color"]
    if not _exists(gdb_path):
        st.warning(f"📂 Address GDB not found at:\n`{gdb_path}`\n"
                   "Map will render without address points. Update the path or download/sync the dataset.")
        return pd.DataFrame(columns=empty_cols)

    try:
        gdf = gpd.read_file(gdb_path, layer="NEWHANOVER")
        if gdf.crs is None:
            gdf.set_crs(epsg=2264, inplace=True)  # example NC State Plane
        gdf = gdf.to_crs(epsg=4326)

        df = gdf[["geometry", "Full_Address"]].copy()
        df["lon"] = df.geometry.x
        df["lat"] = df.geometry.y
        df["color"] = [[0, 0, 255]] * len(df)   # blue points
        df["elevation"] = 0.0  # placeholder elevation; attach later
        return df[empty_cols]
    except Exception as e:
        st.error(f"Failed to read GDB layer 'NEWHANOVER' from:\n`{gdb_path}`\n\n**Error:** {e}")
        return pd.DataFrame(columns=empty_cols)

# IMPORTANT FIX:
# Prefix the parameter with '_' so Streamlit won't try to hash a (Geo)DataFrame.
@st.cache_resource(show_spinner=False)
def attach_elevation(_df_in: pd.DataFrame) -> pd.DataFrame:
    """
    Attach elevation from DEM. If DEM is missing or any error occurs, return df with elevation=0.
    The leading underscore prevents Streamlit from hashing this arg (GeoDataFrame/Pandas isn't hashable).
    """
    df = _df_in.copy()
    if df.empty:
        return df

    if not _exists(dem_path):
        st.info(f"🗺️ DEM not found at:\n`{dem_path}`\nContinuing with elevation=0.")
        return df

    try:
        with rasterio.open(dem_path) as src:
            xs, ys = transform("EPSG:4326", src.crs, df["lon"].values, df["lat"].values)
            df["elevation"] = [val[0] for val in src.sample(zip(xs, ys))]
        df["elevation"] = df["elevation"].fillna(0.0)
        return df
    except Exception as e:
        st.info(f"DEM could not be sampled from:\n`{dem_path}`\nContinuing with elevation=0.\n\nDetails: {e}")
        return df

@st.cache_resource(show_spinner=False)
def load_model_and_artifacts():
    """
    Load ONLY the new neural-network joblib model.
    - If feature/median artifacts are present, use them.
    - If they are missing, provide a sensible default feature list and zero medians
      so predictions can still run without warnings.
    """
    try:
        if not _exists(MODEL_PATH):
            st.warning(f"🧠 Model not found at `{MODEL_PATH}`.\nPrediction will be disabled until this file is available.")
            return None, [], pd.Series(dtype=float)

        model = joblib.load(MODEL_PATH)

        feature_cols = []
        train_medians = pd.Series(dtype=float)

        if _exists(FEAT_PATH):
            with open(FEAT_PATH) as f:
                feature_cols = [ln.strip() for ln in f if ln.strip()]

        if _exists(MEDIANS_PATH):
            with open(MEDIANS_PATH) as f:
                train_medians = pd.Series(json.load(f))

        if not feature_cols:
            feature_cols = [
                "Lat", "Long", "Central_Pressure", "Max_Winds_kt",
                "RMW_nm", "OCI_mb", "SSHWS", "Abs_Lat", "Wind_to_Pressure",
            ]
        if train_medians.empty:
            train_medians = pd.Series({c: 0.0 for c in feature_cols})

        return model, feature_cols, train_medians

    except Exception as e:
        st.error(f"Failed to load model. Prediction disabled.\n\n**Error:** {e}")
        return None, [], pd.Series(dtype=float)

# ----------------------------
# UI
# ----------------------------
st.set_page_config(page_title="Wilmington Hurricane Impact", layout="wide")
st.title("Wilmington Hurricane Impact Simulator")

# Base data (cached)
base_df = load_addresses_df()
df = attach_elevation(base_df)

# Sidebar
st.sidebar.header("Hurricane Builder")
sshws = st.sidebar.selectbox("SSHWS (Category)", options=[0, 1, 2, 3, 4, 5], index=2)

opts = CAT_PRESETS[sshws]
max_winds = st.sidebar.selectbox("Max Winds (kt)", options=opts["Max_Winds_kt"])
central_pressure = st.sidebar.selectbox("Central Pressure (mb)", options=opts["Central_Pressure"])
rmw = st.sidebar.selectbox("Radius of Max Winds (nm)", options=opts["RMW_nm"])
oci = st.sidebar.selectbox("Outer Core Pressure Δ (OCI_mb)", options=opts["OCI_mb"])

predict_button = st.sidebar.button("Predict Hurricane Impact")

rf, FEATURE_COLS, TRAIN_MEDIANS = load_model_and_artifacts()
predicted_size_nm = st.session_state.get("predicted_size_nm")
radius_nm_used = st.session_state.get("radius_nm_used")
center_lat = st.session_state["storm_center"]["lat"]
center_lon = st.session_state["storm_center"]["lon"]


def run_prediction_at(lat_val: float, lon_val: float, inputs: dict):
    """
    Run the model for the given lat/lon and sidebar inputs.
    Returns (pred_nm, radius_nm) or (None, None) on failure.
    """
    if rf is None or not FEATURE_COLS:
        return None, None

    row = {
        "Lat": lat_val,
        "Long": lon_val,
        "Central_Pressure": float(inputs["central_pressure"]),
        "Max_Winds_kt": float(inputs["max_winds"]),
        "RMW_nm": float(inputs["rmw"]),
        "OCI_mb": float(inputs["oci"]),
        "SSHWS": float(inputs["sshws"]),
        "Abs_Lat": abs(lat_val),
        "Wind_to_Pressure": (float(inputs["max_winds"]) / (float(inputs["central_pressure"]) + 1e-6)),
    }
    X_new = pd.DataFrame([{c: row.get(c, np.nan) for c in FEATURE_COLS}])
    X_new = X_new.apply(pd.to_numeric, errors="coerce").fillna(TRAIN_MEDIANS).fillna(0.0)
    X_use = X_new
    try:
        n_expected = None
        if hasattr(rf, "input_shape") and rf.input_shape is not None:
            n_expected = int(rf.input_shape[-1])
        elif hasattr(rf, "n_features_in_"):
            n_expected = int(rf.n_features_in_)
        if n_expected is not None:
            cur_n = X_new.shape[1]
            if cur_n < n_expected:
                pad = pd.DataFrame(np.zeros((1, n_expected - cur_n), dtype=float), columns=[f"__pad_{i}" for i in range(n_expected - cur_n)])
                X_use = pd.concat([X_new.reset_index(drop=True), pad], axis=1)
            elif cur_n > n_expected:
                X_use = X_new.iloc[:, :n_expected]
    except Exception:
        X_use = X_new

    y_pred = rf.predict(np.asarray(X_use).astype("float32"))
    pred_nm = float(np.asarray(y_pred).reshape(-1)[0])
    return pred_nm, pred_nm / 2.0

if predict_button:
    if rf is None or not FEATURE_COLS:
        st.error("Prediction unavailable: model artifacts not found. See warnings above for the expected paths.")
    else:
        st.session_state["pending_inputs"] = {
            "sshws": sshws,
            "max_winds": max_winds,
            "central_pressure": central_pressure,
            "rmw": rmw,
            "oci": oci,
        }
        st.session_state["storm_center"] = {"lat": CENTER_LAT, "lon": CENTER_LON}
        center_lat, center_lon = CENTER_LAT, CENTER_LON

        try:
            predicted_size_nm, radius_nm_used = run_prediction_at(center_lat, center_lon, st.session_state["pending_inputs"])
            st.session_state["predicted_size_nm"] = predicted_size_nm
            st.session_state["radius_nm_used"] = radius_nm_used
        except Exception as e:
            st.error(f"Model failed to predict. Check your artifacts and scikit-learn/TensorFlow versions.\n\n**Error:** {e}")

# Build folium map with click-to-move circle
if folium is None or st_folium is None:
    st.error("Install `folium` and `streamlit-folium` to use the map view (e.g., `pip install folium streamlit-folium`).")
else:
    fmap = folium.Map(location=[center_lat, center_lon], zoom_start=9, tiles="OpenStreetMap")

    # Address dots
    if not df.empty:
        for _, row in df.iterrows():
            folium.CircleMarker(
                location=[row["lat"], row["lon"]],
                radius=2,
                color="#3388ff",
                fill=True,
                fill_opacity=0.7,
                popup=row.get("Full_Address", ""),
            ).add_to(fmap)

    # Draw rings if we have them
    if predicted_size_nm is not None and radius_nm_used is not None:
        radius_m = radius_nm_used * NM_TO_M
        zones = [
            ("outer", radius_m, "#ffd700", 0.25),
            ("middle", radius_m * 0.66, "#ff8c00", 0.35),
            ("inner", radius_m * 0.33, "#c00000", 0.45),
        ]
        for _, rad_m, color, opacity in zones:
            folium.Circle(
                location=[center_lat, center_lon],
                radius=rad_m,
                color=color,
                weight=2,
                fill=True,
                fill_color=color,
                fill_opacity=opacity,
            ).add_to(fmap)
        folium.CircleMarker(
            location=[center_lat, center_lon],
            radius=5,
            color="#800080",
            fill=True,
            fill_color="#800080",
            fill_opacity=0.9,
            popup="Storm center",
        ).add_to(fmap)

    map_data = st_folium(fmap, height=650, width=None, key="main_map")

    # Click to move circle (and optionally recompute) after a prediction exists
    if predicted_size_nm is not None and map_data and map_data.get("last_clicked"):
        new_lat = map_data["last_clicked"]["lat"]
        new_lon = map_data["last_clicked"]["lng"]
        st.session_state["storm_center"] = {"lat": new_lat, "lon": new_lon}
        center_lat, center_lon = new_lat, new_lon
        if st.session_state.get("pending_inputs"):
            try:
                pred_nm, rad_nm = run_prediction_at(center_lat, center_lon, st.session_state["pending_inputs"])
                st.session_state["predicted_size_nm"] = pred_nm
                st.session_state["radius_nm_used"] = rad_nm
            except Exception as e:
                st.warning(f"Repositioned storm center, but prediction refresh failed: {e}")
        st.experimental_rerun()

# Info panel
if predicted_size_nm is not None:
    st.markdown(
        f"### Predicted Hurricane **Radius**: **{radius_nm_used:.2f} nm**  \n"
        f"*(outer yellow = full radius; middle orange ~2/3; inner red ~1/3; model size before halving was {predicted_size_nm:.2f} nm)*"
    )
else:
    st.info("Pick a **category** and inputs, click **Predict Hurricane Impact**, then click the map to move the storm center/rings.")

with st.expander("Notes / Performance"):
    st.markdown(
        "- App caches address data, elevation sampling, and model artifacts to avoid reloading on each interaction.\n"
        "- If you see scikit-learn/TensorFlow version warnings when loading the model, either pin the versions used to save it "
        'or re-save the model with your current environment.'
    )
